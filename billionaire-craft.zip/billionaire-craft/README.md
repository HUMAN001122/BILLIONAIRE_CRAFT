# BILLIONAIRE_CRAFT (React + Vite + Tailwind)

A simple landing page for BILLIONAIRE_CRAFT. Deployable on Vercel/Netlify.

## Quick start

```bash
npm i
npm run dev
```

## Build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Push to GitHub
2. Import repo on https://vercel.com
3. Framework: Vite
4. Build command: `npm run build`
5. Output dir: `dist`

## Notes

- Update text in `src/App.jsx`
- Add your Terms & Conditions and contact details.
- Hook the email form to any provider (Formspree, Basin, Airtable forms, etc.).
