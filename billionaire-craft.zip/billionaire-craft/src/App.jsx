import { useState } from 'react'
import { motion } from 'framer-motion'
import { ArrowRight, Check, Menu, X, Mail, Star, Rocket } from 'lucide-react'

const site = {
  name: 'BILLIONAIRE_CRAFT',
  tagline: 'Invest smart, earn every month',
  cta: 'Join Now',
  description:
    'Invest just ₹1000 once, and receive ₹300 every month for 7 months straight. Simple, transparent*',
  features: [
    { title: 'Low Entry', text: 'Start with only ₹1000 — clear monthly payouts.' },
    { title: 'Fixed Schedule', text: '₹300 per month, for 7 months.' },
    { title: 'Fast Onboarding', text: 'Join in minutes — no complex forms.' },
  ],
  faq: [
    { q: 'How does it work?', a: 'You contribute ₹1000 one time. You then receive ₹300 each month for 7 months.' },
    { q: 'Is this guaranteed?', a: 'Returns are subject to the program’s terms. Read the full T&C and risk disclosure below.' },
    { q: 'When do payouts happen?', a: 'Monthly cycle from your join date. Delays, if any, will be announced.' },
  ],
}

export default function App() {
  const [open, setOpen] = useState(false)
  const [email, setEmail] = useState('')
  const [submitted, setSubmitted] = useState(false)

  const onSubmit = (e) => {
    e.preventDefault()
    if (!email) return
    setSubmitted(true)
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-zinc-50 to-white text-zinc-900">
      {/* Nav */}
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Rocket className="w-6 h-6" />
            <span className="font-semibold text-lg">{site.name}</span>
          </div>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#features" className="hover:opacity-70">Features</a>
            <a href="#faq" className="hover:opacity-70">FAQ</a>
            <a href="#join" className="inline-flex items-center gap-2 bg-zinc-900 text-white px-4 py-2 rounded-2xl shadow hover:shadow-md">
              {site.cta} <ArrowRight className="w-4 h-4" />
            </a>
          </nav>
          <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">
            {open ? <X /> : <Menu />}
          </button>
        </div>
        {open && (
          <div className="md:hidden border-t">
            <div className="px-4 py-3 flex flex-col gap-3 text-sm">
              <a href="#features" onClick={() => setOpen(false)}>Features</a>
              <a href="#faq" onClick={() => setOpen(false)}>FAQ</a>
              <a href="#join" onClick={() => setOpen(false)} className="inline-flex items-center gap-2 bg-zinc-900 text-white px-4 py-2 rounded-2xl w-max">
                {site.cta} <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        )}
      </header>

      {/* Hero */}
      <section className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 gap-10 items-center">
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
            <h1 className="text-4xl md:text-5xl font-black leading-tight">
              Earn monthly with confidence
              <span className="block text-zinc-500 font-semibold text-2xl md:text-3xl mt-2">{site.tagline}</span>
            </h1>
            <p className="mt-5 text-zinc-600 max-w-prose">{site.description}. <span className="italic">*Subject to Terms.</span></p>
            <div className="mt-6 flex gap-3">
              <a href="#features" className="inline-flex items-center gap-2 bg-zinc-900 text-white px-5 py-3 rounded-2xl shadow hover:shadow-md">
                Explore <ArrowRight className="w-4 h-4" />
              </a>
              <a href="#join" className="inline-flex items-center gap-2 border px-5 py-3 rounded-2xl hover:bg-zinc-50">
                Join waitlist
              </a>
            </div>
            <div className="mt-6 flex items-center gap-2 text-zinc-500 text-sm">
              <Star className="w-4 h-4" /> Fast. <Star className="w-4 h-4" /> Simple. <Star className="w-4 h-4" /> Transparent.
            </div>
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="">
            <div className="aspect-video w-full rounded-3xl border shadow-sm bg-white p-4 grid grid-cols-3 gap-3">
              {Array.from({ length: 9 }).map((_, i) => (
                <div key={i} className="rounded-2xl h-24 border bg-gradient-to-br from-zinc-100 to-white"></div>
              ))}
            </div>
            <p className="text-xs text-zinc-500 mt-2">Replace this mock grid with your screenshots or payout proofs.</p>
          </motion.div>
        </div>
      </section>

      {/* Features */}
      <section id="features" className="bg-white border-y">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-bold">Features</h2>
          <div className="grid md:grid-cols-3 gap-6 mt-6">
            {site.features.map((f, idx) => (
              <div key={idx} className="rounded-3xl border p-5 shadow-sm">
                <div className="flex items-center gap-2 text-zinc-700 font-semibold"><Check className="w-4 h-4" /> {f.title}</div>
                <p className="text-zinc-600 mt-2 text-sm">{f.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Email capture */}
      <section id="join" className="bg-white border-y">
        <div className="max-w-6xl mx-auto px-4 py-14 grid md:grid-cols-2 gap-8 items-center">
          <div>
            <h3 className="text-2xl md:text-3xl font-bold">Join the early list</h3>
            <p className="text-zinc-600 mt-2">Get updates on payouts, timelines, and terms. Zero spam.</p>
          </div>
          <form onSubmit={onSubmit} className="flex gap-3">
            <div className="flex-1 flex items-center gap-2 border rounded-2xl px-3">
              <Mail className="w-4 h-4" />
              <input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full py-3 outline-none bg-transparent"
                required
              />
            </div>
            <button className="px-5 py-3 rounded-2xl bg-zinc-900 text-white">Subscribe</button>
          </form>
          {submitted && (
            <div className="md:col-span-2 text-sm text-green-600">Thanks! You’re on the list. (Hook this to your email tool later.)</div>
          )}
        </div>
      </section>

      {/* FAQ */}
      <section id="faq" className="bg-gradient-to-b from-white to-zinc-50">
        <div className="max-w-6xl mx-auto px-4 py-14">
          <h2 className="text-2xl md:text-3xl font-bold">FAQ</h2>
          <div className="mt-6 grid md:grid-cols-2 gap-6">
            {site.faq.map((item, i) => (
              <details key={i} className="rounded-3xl border p-5 shadow-sm">
                <summary className="cursor-pointer font-semibold">{item.q}</summary>
                <p className="text-zinc-600 mt-2 text-sm">{item.a}</p>
              </details>
            ))}
          </div>
          <div className="mt-8 text-xs text-zinc-500">
            <p><strong>Disclaimer:</strong> This site provides information about a private program. Returns are not bank deposits or government-insured. Read Terms & Conditions and Risk Disclosure before joining. Comply with your local laws and taxes.</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-10 text-center text-sm text-zinc-500">
        © {new Date().getFullYear()} {site.name}. All rights reserved.
      </footer>
    </div>
  )
}
